import './post.css';
import { useState } from 'react';

function Post(props){

    let[likesNum,setLikes] = useState(props.likes);
    const[postPath,setPath] = useState(props.PostPath);
    const LikePost = async() => {
        let num = Number(props.likes);
        num++;
        setLikes(String(num));
        let no_likes  = String(num);
        const likedPost = {
            postPath,
            no_likes
        }
        const response = await fetch('http://localhost:4500/like',{
            method: 'POST',
            body: JSON.stringify(likedPost),
            headers: {'Content-Type':'application/json'}
        });

        if(response.ok){console.log("Post Liked");}
    }

    return(<div className='post-box'>
             <div className='poster-info'>
                <img src={props.photo} className='poster-pic' alt='Poster-Picture'></img>
                <p className='poster-name'>{props.name}</p>
             </div>
             <p className='post-detail'>{props.discp}</p>
             <img src={postPath} className='post-pic' alt='post-picture'></img>
             <button className='like' onClick={LikePost}>&#x2764; Like</button>
             <span className='likes'>Total Likes: {likesNum}</span>

    </div>);
}

export default Post;