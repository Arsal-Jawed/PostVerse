import './signup.css';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../Assets/postBlack.png';
 
function SignUp({onClose}){

    const[name,setName] = useState('');
    const[email,setEmail] = useState('');
    const[pass,setPass] = useState('');
    const[cpass,setCPass] = useState('');
    const[photo,setPhoto] = useState(null);
    const [error,setError] = useState('');
    const [imagePreviewUrl, setImagePreviewUrl] = useState(null);

    const [check1,setCheck1] = useState('right-field');
    const [check2,setCheck2] = useState('right-field');
    const [check3,setCheck3] = useState('right-field');
    const [check4,setCheck4] = useState('right-field');

    const handleName = (e) => setName(e.target.value);
    const handleEmail = (e) => setEmail(e.target.value);
    const handlePass = (e) => setPass(e.target.value);
    const handleCPass = (e) => setCPass(e.target.value);

    const handlePhoto = (e) => {

        const file = e.target.files[0];
            setPhoto(file);
    
            if (file) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    setImagePreviewUrl(reader.result);
                };
                reader.readAsDataURL(file);
            } else {
                setImagePreviewUrl(null);
            }
    }

    const Register = async(e) => {

        e.preventDefault();

        if(name.trim()===''){
            setCheck1('wrong-field');
            setError("please enter your name");
            return;
        }else{
            setCheck1('right-field');
            setError('');
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

         if(email.trim()===''){

            setError('please enter your email');
            setCheck2('wrong-field');
            return;

         }else if(!emailRegex.test(email)){

            setError('please enter a valid email');
            setCheck2('wrong-field');
            return;
         }else{

            setError('');
            setCheck2('right-field');
         }

         if(pass.trim()===''){
            setError('please set a password');
            setCheck3('wrong-field');
            return;
         }else if(pass.length < 8 || !/[!@#$%^&*(),.?":{}|<>]/.test(pass)){
            setError('password must contains 8 and 1 special character');
            setCheck3('wrong-field');
            return;
         }else{
            setError('');
            setCheck3('right-field');
         }

         if(cpass.trim()===''){
            setError('please confirm your password');
            setCheck4('wrong-field');
            return;
         }else if(pass!==cpass){
            setError('passwords do not match');
            setCheck4('wrong-field');
            return;
         }else{
            setError('');
            setCheck4('right-field');
         }

         if(photo===null){
            setError("please select a photo");
            return;
         }else{
            setError('');
         }

         const formData = new FormData();
         formData.append('name',name);
         formData.append('email',email);
         formData.append('password',pass);
         formData.append('photo',photo);

         const response = await fetch('http://192.168.100.115:4500/signup',{
            method: 'POST',
            body: formData
         })

         if(response.ok){
            onClose();
            setError('');
         }else{
            setError('failed to signup');
         }
         

    }

    return(
        <div className='sign-overlay'>
    <div className='signup-container'>
             <img src={logo} className='sign-logo'></img>
             <input 
            className='sign-field'
            placeholder='Enter Full Name'
            type='text'
            id={check1}
            value={name}
            onChange={handleName}
            ></input>
            <input 
            className='sign-field'
            placeholder='Enter Email'
            type='email'
            id={check2}
            value={email}
            onChange={handleEmail}
            ></input>
            <input 
            className='sign-field'
            placeholder='Enter Password'
            type='password'
            id={check3}
            value={pass}
            onChange={handlePass}
            ></input>
            <input 
            className='sign-field'
            placeholder='Confirm Password'
            type='password'
            id={check4}
            value={cpass}
            onChange={handleCPass}
            ></input>
            <div className='preview-container'>
                        {imagePreviewUrl && <img src={imagePreviewUrl} alt='Preview' style={{ width: '140px', height: '80px', objectFit: 'cover' }} />}
             </div>
             <label htmlFor="fileInput" className="upload-button"> Upload Image</label>
            <input
                        type="file"
                        accept="image/jpeg, image/png, image/jpg"
                        onChange={handlePhoto}
                        className='photo'
                        id="fileInput"
                        style={{ display: 'none' }}
            ></input>
            <button className='signup' onClick={Register}>Sign Up</button>
            <p className='error'>{error}</p>
             
    </div>
    </div>);
}

export default SignUp;