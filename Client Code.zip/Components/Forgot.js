import './forgot.css';
import pic from '../Assets/forget.png';
import { useState } from 'react';

function Forgot({onClose}){

    const[fmail,setFmail] = useState('');
    const[fpass,setFPass] = useState('');
    const[cfpass,setCFPass] = useState('');
    const[vision1,setVision1] = useState('appear');
    const[vision2,setVision2] = useState('disappear');
    const[error,setError] = useState('');

    const handleFmail = (e) => setFmail(e.target.value);
    const handleFPass = (e) => setFPass(e.target.value);
    const handleCFPass = (e) => setCFPass(e.target.value);

    const SendRequest = async() => {

        if(fmail.trim()===''){
            setError('please enter your email');
            return;
        }else{
        setError('');
        const email = fmail;
        const response = await fetch('http://localhost:4500/forget',{
            method: 'POST',
            body: JSON.stringify({email}),
            headers: {'Content-Type':'application/json'}
        });

        if(response.ok){
            setVision1('disappear');
            setVision2('appear');
            setError('');
        }else{
            setError('Email Not Found');
            return;
        }}}

    const UpdatePassword = async() => {
        if(fpass.trim()===''){
            setError('please enter your new password');
            return;
        }else{
            setError('');
        }

        if(cfpass.trim()===''){
            setError('please confirm your new passowrd');
            return;
        }else if(fpass!=cfpass){
            setError('passwords do not match');
            return;
        }else{setError('');}

        const response = await fetch('http://localhost:4500/updatePass',{
            method: 'POST',
            body: JSON.stringify({fmail,fpass}),
            headers: {'Content-Type':'application/json'}
        });

        if(response.ok){
            setError('');
            onClose();
        }
    }
    
    return(
        <div className='forgot-overlay'>
        <div className='forgot-container'>
        <img src={pic} className='forget-pic'></img>
         <div className='f1' id={vision1}>
        <label for="fmail" className='flabel'>Email:</label>
         <input
            type='text'
            id='fmail'
            className='Fmail'
            placeholder='Enter Your Email'
            value={fmail}
            onChange={handleFmail}
        ></input>
        <button className='fbutton' onClick={SendRequest}>Send Request</button>
        <p className='error'>{error}</p>
        </div>
        <div className='f1' id={vision2}>
        <label for="fpass" className='flabel'>Password:</label>
        <input
            type='password'
            id='fpass'
            className='Fmail'
            placeholder='Enter New Password'
            value={fpass}
            onChange={handleFPass}
        ></input>
        <label for="cfpass" className='flabel'>Confirm Password:</label>
        <input
            type='password'
            id='cfpass'
            className='Fmail'
            placeholder='Confirm New Password'
            value={cfpass}
            onChange={handleCFPass}
        ></input>
        <button className='fbutton' onClick={UpdatePassword}>Update Password</button>
        <p className='error'>{error}</p>
        </div>
        </div></div>
    );
}

export default Forgot;