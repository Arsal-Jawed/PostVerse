import MenuBar from './MenuBar';
import './start.css';
import { useState, useEffect } from 'react';
import pic from '../Assets/start-pic.png';
import card_pic_1 from '../Assets/card-pic-1.png';
import card_pic_2 from '../Assets/card-pic-2.png';
import { useNavigate } from 'react-router-dom';
import Forgot from './Forgot';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebookF, faTwitter, faInstagram, faLinkedinIn } from '@fortawesome/free-brands-svg-icons';

function Start(){

    const[email,setEmail] = useState('');
    const[password,setPassword] = useState('');
    const[error,setError] = useState('');
    const [check1,setCheck1] = useState('right-field');
    const [check2,setCheck2] = useState('right-field');
    const[isopen,setOpen] = useState(false);

    const navigate = useNavigate();

    const handleEmail = (e) => setEmail(e.target.value);
    const handlePassword = (e) => setPassword(e.target.value);

    const Login = async(e) => {

        e.preventDefault();

        if(email.trim()===''){
            setCheck1('wrong-field');
            setError('please enter your email');
            return;
        }else{
            setCheck1('right-field');
            setError('');
        }

        if(password.trim()===''){
            setCheck2('wrong-field');
            setError('please enter your password');
            return;
        }else{
            setCheck2('right-field');
            setError('');
        }

        const response = await fetch('http://localhost:4500/login',{
            method: 'POST',
            body: JSON.stringify({email,password}),
            headers: {'Content-Type': 'application/json'}
        });

        if(response.ok){
            const data = await response.json();
            localStorage.clear();
            localStorage.setItem("user",JSON.stringify(data));
            navigate('/main');
        }else{
            setError('invalid username or password');
        }
    }

    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    useEffect(() => {
        AOS.init({ once: true });
      }, []);

    return(
        <div className='start-container'>
            <MenuBar/>
            <div className='login-container'>
                <div className='login-box'>
                    <h1 className='login-head-1'>Welcome!</h1>
                    <p className='login-head-2'>To PostVerse</p>
                    <p className='quote-1'>"every thought finds its voice and every story begins a new"</p>
                    <input
                    type='email'
                    className='login-field'
                    placeholder='Enter Your Email'
                    value={email}
                    onChange={handleEmail}
                    id={check1}
                    ></input>
                    <input
                    type='password'
                    className='login-field'
                    placeholder='Enter Your Password'
                    value={password}
                    onChange={handlePassword}
                    id={check2}
                    ></input>
                    <button className='login' onClick={Login}>Login</button>
                    <p className='forgot-pass' onClick={handleOpen}>Forget Passsword ?</p>
                    <p className='l-error'>{error}</p>
                </div>
                {isopen && <Forgot onClose={handleClose}></Forgot>}
                <div className='login-pic-container'>
                    <img src={pic} className='login-pic'></img>
                </div>
            </div>
            <div className='start-1'>
                <h1 className='start-1-head'>"Discover endless avenues of entertainment with PostVerse"</h1>
                <div className='card-container'>
                <div className='start-card'>
                    <h5 className='card-head'>Post Creation</h5>
                    <img src={card_pic_1} className='card-pic'></img>
                    <p className='card-discp'>Craft your narratives effortlessly with our intuitive post creation tools. From text to multimedia, express yourself in vibrant detail with easy-to-use formatting options and media integration</p>
                </div>
                <div className='start-card'>
                    <h5 className='card-head'>Dynamic Commenting</h5>
                    <img src={card_pic_2} className='card-pic'></img>
                    <p className='card-discp'>Engage in meaningful conversations with our dynamic commenting system. Seamlessly reply, like, and interact with fellow users' posts, fostering a vibrant community of shared ideas and perspectives</p>
                </div>
                </div>
            </div>
            <div className='start-2'>
        <div className="footer-text" data-aos="fade-up">
        <p className='footer_text1'>Stay connected with us:</p>
        <div className="social-icons">
        <a href="#"><FontAwesomeIcon icon={faFacebookF} /></a>
        <a href="#"><FontAwesomeIcon icon={faTwitter} /></a>
        <a href="#"><FontAwesomeIcon icon={faInstagram} /></a>
        <a href="#"><FontAwesomeIcon icon={faLinkedinIn} /></a>
        </div>
      </div>
               </div>
        </div>
    );
}

export default Start;