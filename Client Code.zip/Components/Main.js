import './main.css';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Post from './Post';
import icons from '../Assets/icons.gif';

function Main(){

    const StoredData = localStorage.getItem("user");
    const user = JSON.parse(StoredData);

    const[post,setPost] = useState(null);
    const [imagePreviewUrl, setImagePreviewUrl] = useState(null);
    const [discp, setDiscp] = useState('');
    const[posts,setPosts] = useState([]);

    const navigate = useNavigate();

    const handlePost = (e) => {

        const file = e.target.files[0];
            setPost(file);
    
            if (file) {
                const reader = new FileReader();
                reader.onloadend = () => {
                    setImagePreviewUrl(reader.result);
                };
                reader.readAsDataURL(file);
            } else {
                setImagePreviewUrl(null);
            }
    }

    const handleDiscp = (e) => setDiscp(e.target.value);

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    const fetchPosts = async() => {
        const response = await fetch('http://localhost:4500/posts');
        const data = await response.json();
        setPosts(shuffleArray(data));
    }
    const addPost = async(e) => {

        if(discp.trim()==='' || post===null){

            alert('Error! Upload a Post and enter description to Create a New Post');
            return;
        }else{
            const formData = new FormData();
            formData.append('post',post);
            formData.append('discp',discp);
            formData.append('name',user.name);
            formData.append('photo',user.urlname);
            formData.append('likes','0');

            console.log("This Function Called");
            const response = await fetch('http://localhost:4500/createPost',{

            method: 'POST',
            body: formData
        });
            if(response.ok){
                setPost(null);
                setDiscp('');
                setImagePreviewUrl(null);
            }
    }}

    const LogOut = () => navigate('/');

    useEffect(()=>{
        fetchPosts();
    },[]);
    return(
    <div className='main-container'>
               <div className='profile-container'>
                      <img src={user.urlname} className='profile-pic'></img>
                      <h1 className='profile-name'>{user.name}</h1>
                      <p className='profile-email'>{user.email}</p>
                      <button className='logout' onClick={LogOut}>Log Out</button>
                      <div className='add-post-container'>
                      <div className='preview-container'>
                        {imagePreviewUrl && <img src={imagePreviewUrl} alt='Preview' style={{ width: '20vw', height: '22vh', objectFit: 'cover'}} />}
             </div>
                        <label htmlFor="fileInput" className="upload-post"> Upload Post</label>
               <input
                        type="file"
                        accept="image/jpeg, image/png, image/jpg"
                        onChange={handlePost}
                        className='post'
                        id="fileInput"
                        style={{ display: 'none' }}
               ></input>
                      <textarea 
                      className='post-discp' 
                      placeholder='enter post description....'
                      value={discp}
                      onChange={handleDiscp}
                      ></textarea>
                      <button className='createPost' onClick={addPost}>Create Post</button>
                      </div>
               </div>
               <div className='posts-container'>
                {posts.map((pst)=>(
                    <Post
                    photo = {pst.photo}
                    name = {pst.name}
                    PostPath = {pst.PostPath}
                    discp = {pst.discp}
                    likes = {pst.likes}
                    ></Post>
                ))}
               </div>
               <img src={icons} className='icons'></img>
               
    </div>);
}

export default Main;