import './menubar.css';
import SignUp from './SignUp';
import { useState } from 'react';
import logo from '../Assets/postWhite.png';

function MenuBar(){

    const[isOpen,setOpen] = useState(false);

    const handleOpen = (e) => setOpen(true);
    const handleClose = (e) => setOpen(false);

    return(
        <div className='bar'>

        <div className='bar-logo-container'><img src={logo} className='bar-logo'></img></div>
        <div className='bar-buttons-container'>
            <button className='bar-buttons'>Home</button>
            <button className='bar-buttons'>About Us</button>
            <button className='bar-buttons'>Contact</button>
        </div>
        <div>{isOpen && <SignUp onClose={handleClose}></SignUp>}</div>
        <div><button className='bar-signup' onClick={handleOpen}>Sign Up</button></div>
        </div>
    );
}

export default MenuBar;