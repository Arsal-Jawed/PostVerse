const express = require('express');
const {MongoClient} = require('mongodb');
const cors = require('cors');
const bodyParser = require('body-parser');
const url = 'mongodb://127.0.0.1:27017';
const database = 'postverse';
const fileupload = require('express-fileupload');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(fileupload());

const ConnectDB = async() => {

    const client = new MongoClient(url);
    await client.connect();
    const db = client.db(database);
    const user = db.collection('user');
    const post = db.collection('post');

    app.post('/signup', async(req,res)=>{

        const {name, email, password} = req.body;
        const PhotoFile = req.files.photo;
        const urlname = `/assets/${PhotoFile.name}`;
        const filePath = `D:/AREX Projects/PostVerse/Client/postverse/public/assets/${PhotoFile.name}`;
        PhotoFile.mv(filePath);
        const info = {name, email, password, urlname};
        try{
            await user.insertOne(info);
            res.status(200).json(info);console.log('SignUp Success');
        }catch(err){res.status(500).json('Failed to Sign Up'); console.log('SignUp Failed');}
    });

    app.post('/login', async(req,res)=>{
      const  {email, password} = req.body;
      const result = await user.findOne({email});
      if(result && result.password===password){
        res.status(200).json(result);
      }else{
        res.status(500);
      }});

      app.post('/createPost', async(req,res)=>{
        const{discp,name,photo,likes} = req.body;
        const PhotoFile = req.files.post;
        const PostPath = `/posts/${PhotoFile.name}`;
        const filePath = `D:/AREX Projects/PostVerse/Client/postverse/public/posts/${PhotoFile.name}`;
        PhotoFile.mv(filePath);
        try{
            await post.insertOne({PostPath,discp,name,photo,likes});
            res.status(200).json({message:"Post Successfully Created"}); console.log("Post Successfully Created");
        }catch(err){res.status(500); console.log('Failed to Create a Post');}    
      });

      app.get('/posts', async(req,res)=>{
        const posts = await post.find().toArray();
        res.status(200).json(posts);
      });

      app.post('/like', async(req,res)=>{
       try{
        const{postPath,no_likes} = req.body;
        console.log(postPath + " " + no_likes);
        await post.updateOne({PostPath: postPath},{$set:{likes:no_likes}});
        res.status(200).json({message: "Likes Updated"});
      }catch(err){res.status(500); console.log(err);}
      });

      app.post('/forget', async(req,res)=>{
        const{email} = req.body;
       const found =  await user.findOne({email});
        if(found){
          res.status(200).json({message: "Email Found"});
      }else{
        res.status(500).json({message: "Email not Found"}); 
      }});

      app.post('/updatePass', async(req,res)=>{
        try{
        const{fmail,fpass} = req.body;
        await user.updateOne({email: fmail}, {$set:{password: fpass}});
        res.status(200).json({message: "Password Updated Successfully"});
        }catch(err){res.status(500).json({message: "Failed to Update Password"});}

      })

    app.listen(4500, ()=>{console.log('Server Started');});
}

ConnectDB();